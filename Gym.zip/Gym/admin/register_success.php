<?php
header('location:a.php?reg=1');
?>